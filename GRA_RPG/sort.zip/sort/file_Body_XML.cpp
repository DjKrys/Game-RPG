#include "file_Body_XML.h"
#include <iostream>

std::map<std::string, int> file_Body_XML::Load_Settings()
{
	std::map< std::string, int> settings{};
	Text::getText().print("notImplementedException");
	return settings;
}
