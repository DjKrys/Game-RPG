#pragma once

enum Location
{
	Kitchen,
	Garage,
	Bedroom,
	Corridor,
	Forrest,
	River,
	Street,
};

enum Option
{
	Action,
	Travel,
	Fight,
};