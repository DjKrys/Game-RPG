#pragma once
class NPC
{
public:
	virtual void info() = 0;
};

