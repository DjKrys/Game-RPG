#include "adapter_item_NPC.h"



adapter_item_NPC::adapter_item_NPC()
{
}


adapter_item_NPC::~adapter_item_NPC()
{
}

adapter_item_NPC::adapter_item_NPC(std::string name, int hp)
{
}
