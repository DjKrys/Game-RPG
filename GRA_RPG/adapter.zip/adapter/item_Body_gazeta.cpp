#include "item_Body_gazeta.h"
#include <iostream>

void item_Body_gazeta::info()
{
	std::cout << "Napotkales bardzo ciekawa gazete, ktora podniosles" << std::endl;
}
