#include "item_Body_noz.h"
#include <iostream>


void item_Body_noz::info()
{
	std::cout << "Napotkales bardzo ostry noz, ktorego wziales" << std::endl;
}
