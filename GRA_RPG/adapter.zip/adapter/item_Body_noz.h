#pragma once
#include "item_Body.h"

class item_Body_noz : public item_Body
{
public:
	virtual void info();
};