#pragma once


class item_Body
{
public:
	virtual void info() = 0;

	virtual ~item_Body() = default;
};

